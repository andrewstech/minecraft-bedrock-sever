C toby109tt 
This pack and all its assets are owned and created by me.
https://www.patreon.com/toby109tt
https://www.artstation.com/toby109tt

PLEASE DO NOT reupload my pack!
The only real and legit download site is https://www.planetminecraft.com/texture_pack/epic-adventures-by-toby109tt-x32-wip/
That's the one I toby109tt have uploaded my pack to.
DO NOT trust any other sites!

You may not use these assets in your mod or own texture pack.
You can however play with it on YouTube videos and Twitch and such obviously.

PLEASE Do not breach the above statements!
If you do I retain the right to give you a DMCA takedown.